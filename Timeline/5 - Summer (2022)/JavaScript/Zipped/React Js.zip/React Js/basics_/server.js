function handler(req, res){
    if (req.method == "POST") {
        const body = JSON.parse(req.body)
    }
}

handler()