<?php
    if (isset($_GET['user_Input'])){
        echo $_GET['user_Input']
    }
?>