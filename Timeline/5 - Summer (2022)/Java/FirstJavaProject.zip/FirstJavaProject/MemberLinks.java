import java.util.Scanner;

public class MemberLinks {
    public static void main (String[] args){
        System.out.print("What is the streamer's name: ");
        Scanner nameInput = new Scanner(System.in);
        String name = nameInput.nextLine();
        nameInput.close();
        
        String [] = "", "";

        int questionLoopNumber = 0;

        while (questionLoopNumber < 10){
            System.out.print("What is their %s", );
        };
    }
}
