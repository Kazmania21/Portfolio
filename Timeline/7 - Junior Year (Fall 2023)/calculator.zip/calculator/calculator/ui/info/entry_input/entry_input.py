from .. import interfaces


class EntryInputInfo(interfaces.IEntryInputInfo):
    ...
