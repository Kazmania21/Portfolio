from .. import interfaces


class HistoryInfo(interfaces.IHistoryInfo):
    ...
