let codedSequenceEl =document.getElementById("codedSequence-El")
userInput1El = document.getElementById("userInput1-El")
userInput2El = document.getElementById("userInput2-El")
userInput3El = document.getElementById("userInput3-El")

function translateCode() {
    let codedSequenceCharacters = codedSequenceEl.textcontent[codedSequenceEl.textContent.length]
    console.log(codedSequenceCharacters)
}